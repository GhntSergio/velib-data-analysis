# Analyse des données Vélib en temps réel 🚲📊

## Description
Ce projet permet d'explorer et d'analyser les données en temps réel du service Vélib' à Paris.
Il comprend :
- **Extraction des données** en temps réel depuis l'API Vélib.
- **Stockage des données** dans un fichier CSV.
- **Surveillance des stations** pour détecter les vélos disponibles.
- **Visualisation interactive** des données avec Matplotlib et Folium.

## Structure du projet 📁
```
velib-data-analysis/
│── data/                 # Stockage des fichiers CSV et autres données brutes
│   ├── velib_data.csv    
│
│── logs/
│   ├── velib_monitoring.log    
│── notebooks/            # Notebooks Jupyter pour l'analyse et visualisation
│   ├── velib_visualisation.ipynb
│
│── velib_data_analysis/   # 🔹 Le package Python & Scripts Python pour extraction et surveillance
│   ├── __init__.py        # 🔹 pour le package
│   ├── velib_monitoring.py
│
│── docs/                 # Documentation du projet (README, notes, etc.)
│   ├── README.md
│
│── requirements.txt      # Liste des dépendances Python
│── .gitignore            # Exclusion des fichiers inutiles
│── LICENSE               # Licence du projet
│── setup.py              # projet en package Python
```

## Installation 🛠️
1. **Cloner le projet** :
   ```sh
   git clone https://github.com/GhntSergio/velib-data-analysis.git
   cd velib-data-analysis
   ```
2. **Créer un environnement virtuel et installer les dépendances** :
   ```sh
   python -m venv venv
   source venv/bin/activate  # Sur Windows : venv\Scripts\activate
   pip install -r requirements.txt
   ```

## Utilisation 🚀
### 1️⃣ Exécuter le script de collecte et surveillance des données :
```sh
python scripts/velib_monitoring.py
```
Ce script récupère les données en temps réel, les stocke dans un fichier CSV et surveille les stations sans vélos.

### 2️⃣ Ouvrir le notebook de visualisation :
Lancer Jupyter Notebook et exécuter les analyses interactives :
```sh
jupyter notebook notebooks/velib_visualisation.ipynb
```

## Technologies utilisées 🛠️
- **Python** (requests, pandas, seaborn, matplotlib, folium)
- **Jupyter Notebook** pour l'analyse interactive
- **API OpenDataSoft** pour l'accès aux données Vélib

## Améliorations possibles 🚀
- Ajouter des notifications par e-mail ou Telegram
- Héberger une application web pour suivre les vélos en direct
- Optimiser le stockage et l'analyse des données

## Licence 📜
Ce projet est sous licence MIT. Voir le fichier [LICENSE](LICENSE) pour plus de détails.

---

✉️ **Contact & Contributions**
Si vous avez des idées d'amélioration ou des suggestions, n'hésitez pas à créer une *issue* ou une *pull request* sur le dépôt GitHub ! 😊

